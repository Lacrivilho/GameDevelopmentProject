﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace LlockhamIndustries.Misc
{
    public class Blood : MonoBehaviour
    {
        [HideInInspector]
        public Bleeder source;
    }
}