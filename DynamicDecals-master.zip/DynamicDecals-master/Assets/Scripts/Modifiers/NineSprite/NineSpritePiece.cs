﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace LlockhamIndustries.Decals
{
    public class NineSpritePiece : MonoBehaviour
    {
        //Empty component used to determing if renderer is piece of ninesprite
        //You should never see this component
    }
}